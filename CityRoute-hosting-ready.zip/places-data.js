/* Verified-name Moscow starter catalogue; kept locally so place search never depends on a timed-out service.
   Coordinates are approximate map anchors. Always open Yandex for the exact entrance / current status.
   This dataset is NOT live venue availability and is not represented as Yandex Places API data. */
(()=>{
'use strict';
const raw=[
/* Landmarks and architecture */
['Красная площадь','sights','sights',55.7539,37.6208,'Красная площадь'],
['Собор Василия Блаженного','sights','sights',55.7525,37.6231,'Собор Василия Блаженного'],
['Московский Кремль','sights','sights',55.7510,37.6175,'Московский Кремль'],
['Большой театр','culture','theatre',55.7603,37.6187,'Большой театр'],
['Манежная площадь','sights','sights',55.7562,37.6149,'Манежная площадь (Москва)'],
['Казанский собор на Красной площади','sights','sights',55.7559,37.6192,'Казанский собор (Москва)'],
['Храм Христа Спасителя','sights','sights',55.7446,37.6056,'Храм Христа Спасителя'],
['Арбат','sights','sights',55.7495,37.5915,'Арбат'],
['Никольская улица','sights','sights',55.7575,37.6239,'Никольская улица (Москва)'],
['Кузнецкий Мост','sights','sights',55.7611,37.6251,'Кузнецкий Мост (улица)'],
['Тверская улица','sights','sights',55.7632,37.6059,'Тверская улица (Москва)'],
['Патриаршие пруды','parks','parks',55.7636,37.5928,'Патриаршие пруды'],
['Чистые пруды','parks','parks',55.7618,37.6414,'Чистые пруды'],
['Камергерский переулок','sights','sights',55.7600,37.6144,'Камергерский переулок'],
['Дом Пашкова','sights','sights',55.7492,37.6089,'Дом Пашкова'],
['Высотка на Котельнической набережной','sights','sights',55.7467,37.6436,'Жилой дом на Котельнической набережной'],
['Московский международный деловой центр','sights','sights',55.7499,37.5399,'Московский международный деловой центр'],
['Старый Гостиный двор','sights','sights',55.7536,37.6265,'Гостиный двор (Москва)'],
['Московский зоопарк','culture','entertainment',55.7604,37.5770,'Московский зоопарк'],
['Воробьёвы горы — смотровая площадка','water','viewpoint',55.7090,37.5421,'Воробьёвы горы'],
['Останкинская телебашня','sights','sights',55.8197,37.6117,'Останкинская телебашня'],
['МГУ — главное здание','sights','sights',55.7034,37.5308,'Главное здание МГУ'],
['Триумфальная арка','sights','sights',55.7367,37.5164,'Триумфальная арка (Москва)'],
['Измайловский кремль','sights','sights',55.7952,37.7502,'Измайловский кремль'],
['ВДНХ — арка главного входа','sights','sights',55.8262,37.6394,'ВДНХ'],
/* Parks */
['Парк «Зарядье»','parks','parks',55.7520,37.6286,'Зарядье (парк)'],
['Александровский сад','parks','parks',55.7518,37.6141,'Александровский сад (Москва)'],
['Парк Горького','parks','parks',55.7296,37.6022,'Центральный парк культуры и отдыха имени Горького'],
['Парк искусств «Музеон»','parks','parks',55.7354,37.6067,'Музеон (парк искусств)'],
['Нескучный сад','parks','parks',55.7168,37.5894,'Нескучный сад'],
['Сад «Эрмитаж»','parks','parks',55.7700,37.6094,'Сад «Эрмитаж»'],
['Парк «Сокольники»','parks','parks',55.7928,37.6762,'Сокольники (парк)'],
['ВДНХ — центральная аллея','parks','parks',55.8294,37.6328,'ВДНХ'],
['Главный ботанический сад','parks','parks',55.8415,37.6016,'Главный ботанический сад имени Н. В. Цицина РАН'],
['Парк «Коломенское»','parks','parks',55.6667,37.6681,'Коломенское'],
['Парк «Царицыно»','parks','parks',55.6154,37.6830,'Царицыно (музей-заповедник)'],
['Измайловский парк','parks','parks',55.7740,37.7745,'Измайловский парк'],
['Парк Победы на Поклонной горе','parks','parks',55.7305,37.5077,'Парк Победы (Москва)'],
['Филёвский парк','parks','parks',55.7508,37.4821,'Филёвский парк'],
['Парк «Красная Пресня»','parks','parks',55.7538,37.5519,'Красная Пресня (парк)'],
['Ходынское поле','parks','parks',55.7860,37.5289,'Ходынское поле (парк)'],
['Битцевский лес','parks','parks',55.6205,37.5586,'Битцевский лес'],
['Ландшафтный парк «Тёплый Стан»','parks','parks',55.6323,37.4925,'Тёплый Стан (лесопарк)'],
['Парк «Тропарёво»','parks','parks',55.6359,37.4809,'Тропарёво (ландшафтный заказник)'],
['Парк у Голубинских прудов','parks','parks',55.5978,37.5509,'Ясенево'],
['Парк «Кусково»','parks','parks',55.7360,37.8032,'Кусково'],
['Екатерининский парк','parks','parks',55.7834,37.6123,'Екатерининский парк (Москва)'],
/* Waterfronts and scenic walks */
['Парящий мост в «Зарядье»','water','viewpoint',55.7499,37.6329,'Зарядье (парк)'],
['Крымская набережная','water','water',55.7335,37.6011,'Крымская набережная'],
['Москворецкая набережная','water','water',55.7489,37.6349,'Москворецкая набережная'],
['Болотная набережная','water','water',55.7457,37.6116,'Болотная набережная'],
['Фрунзенская набережная','water','water',55.7239,37.5866,'Фрунзенская набережная'],
['Пресненская набережная','water','water',55.7479,37.5403,'Пресненская набережная'],
['Ростовская набережная','water','water',55.7370,37.5768,'Ростовская набережная'],
['Пушкинская набережная','water','water',55.7227,37.5888,'Пушкинская набережная'],
['Берсеневская набережная','water','water',55.7434,37.6090,'Берсеневская набережная'],
['Патриарший мост','water','viewpoint',55.7428,37.6073,'Патриарший мост'],
['Парк «Серебряный Бор»','parks','parks',55.7810,37.4314,'Серебряный Бор'],
/* Museums and theatres */
['Государственная Третьяковская галерея','culture','museum',55.7414,37.6208,'Третьяковская галерея'],
['ГМИИ имени Пушкина','culture','museum',55.7471,37.6051,'Государственный музей изобразительных искусств имени А. С. Пушкина'],
['Государственный исторический музей','culture','museum',55.7555,37.6177,'Государственный исторический музей'],
['Музей Москвы','culture','museum',55.7371,37.5946,'Музей Москвы'],
['Музей космонавтики','culture','museum',55.8238,37.6387,'Мемориальный музей космонавтики'],
['Дарвиновский музей','culture','museum',55.6899,37.5627,'Государственный Дарвиновский музей'],
['Музей современного искусства «Гараж»','culture','museum',55.7292,37.6016,'Музей современного искусства «Гараж»'],
['Музей Михаила Булгакова','culture','museum',55.7671,37.5933,'Музей Михаила Булгакова'],
['Еврейский музей и центр толерантности','culture','museum',55.7902,37.6191,'Еврейский музей и центр толерантности'],
['Музей-заповедник «Коломенское»','culture','museum',55.6663,37.6674,'Коломенское'],
['Музей-усадьба «Кусково»','culture','museum',55.7363,37.8060,'Кусково'],
['МХТ имени А. П. Чехова','culture','theatre',55.7601,37.6146,'Московский Художественный театр имени А. П. Чехова'],
['Театр имени Евгения Вахтангова','culture','theatre',55.7482,37.5900,'Театр имени Е. Б. Вахтангова'],
['Московский планетарий','culture','museum',55.7613,37.5822,'Московский планетарий'],
['Центр документального кино','culture','cinema',55.7468,37.5878,'Центр документального кино'],
/* Food and bakeries — named outlets with an identifiable address */
['«Кофемания» на Большой Никитской, 13','food','cafe',55.7549,37.6082,'','Большая Никитская улица, 13'],
['«Кофемания» на Новом Арбате, 19','food','cafe',55.7526,37.5888,'','Новый Арбат, 19'],
['«Кофемания» на Покровке, 18','food','cafe',55.7601,37.6433,'','Покровка, 18'],
['Кафе «Пушкинъ»','food','restaurant',55.7640,37.6052,'','Тверской бульвар, 26А'],
['Кондитерская «Кафе Пушкинъ»','food','bakery',55.7640,37.6052,'','Тверской бульвар, 26'],
['AVA Cafe в ГУМе','food','cafe',55.7547,37.6220,'','Красная площадь, 3'],
['Столовая №57 в ГУМе','food','restaurant',55.7547,37.6220,'','Красная площадь, 3'],
['«Теремок» на Никольской','food','restaurant',55.7580,37.6257,'','Никольская улица, 8/1'],
['Гастромаркет «Вокруг света»','food','restaurant',55.7582,37.6259,'','Никольская улица, 10'],
['Ресторан «Рубель» в ГУМе','food','restaurant',55.7547,37.6220,'','Красная площадь, 3'],
['«Буше» в Центральном детском магазине','food','bakery',55.7595,37.6256,'','Театральный проезд, 5'],
['Кондитерская «Счастье» в ГУМе','food','bakery',55.7547,37.6220,'','Красная площадь, 3'],
['Кофемания «Ленинский рынок»','food','cafe',55.6541,37.5238,'','Ленинский проспект, 108'],
/* Shopping (shown only when explicitly selected) */
['ГУМ','malls','malls',55.7549,37.6225,'ГУМ','Красная площадь, 3'],
['ЦУМ','malls','malls',55.7610,37.6193,'ЦУМ (Москва)','Петровка, 2'],
['ТЦ «Авиапарк»','malls','malls',55.7904,37.5319,'Авиапарк (торговый центр)','Ходынский бульвар, 4'],
['ТЦ «Европейский»','malls','malls',55.7451,37.5662,'Европейский (торговый центр)','площадь Киевского Вокзала, 2'],
/* Address-verified food outlets: appended to preserve historical catalogue IDs. */
['«Шава-гриль» в Ясенево','food','restaurant',55.609507,37.526663,'','Литовский бульвар, 4'],
['Кафе «Оазис» в Ясенево','food','cafe',55.612019,37.554915,'','улица Рокотова, 2А'], 
/* Extra curated walking spots; approximate anchors, not verified entrances. */
['Новая Третьяковка','culture','museum',55.7355,37.6055,'Новая Третьяковка'],
['Дом культуры «ГЭС-2»','culture','museum',55.7421,37.609,'ГЭС-2 (дом культуры)'],
['Мультимедиа Арт Музей','culture','museum',55.742,37.598,'Мультимедиа Арт Музей'],
['Музей архитектуры имени Щусева','culture','museum',55.7521,37.6061,'Государственный научно-исследовательский музей архитектуры имени А. В. Щусева'],
['Ботанический сад «Аптекарский огород»','parks','parks',55.7817,37.637,'Аптекарский огород'],
['Северный речной вокзал','sights','sights',55.8543,37.4765,'Северный речной вокзал'],
['Парк Северного речного вокзала','parks','parks',55.8539,37.4747,'Северный речной вокзал'],
['Живописный мост','water','viewpoint',55.7747,37.4382,'Живописный мост'],
['Ландшафтный парк «Митино»','parks','parks',55.8427,37.3548,'Митинский ландшафтный парк'],
['Парк 50-летия Октября','parks','parks',55.6754,37.5037,'Парк 50-летия Октября (Москва)'],
['Парк «Покровское-Стрешнево»','parks','parks',55.8249,37.453,'Покровское-Стрешнево (парк)'],
['Усадьба «Покровское-Стрешнево»','sights','sights',55.8262,37.4517,'Покровское-Стрешнево'],
['Парк «Кузьминки»','parks','parks',55.69,37.7707,'Кузьминки (парк)'],
['Усадьба «Люблино»','sights','sights',55.681,37.7401,'Люблино (усадьба)'],
['Национальный парк «Лосиный Остров»','parks','parks',55.8323,37.7651,'Лосиный Остров'],
['Парк «Останкино»','parks','parks',55.8274,37.6083,'Останкино (парк)'],
['Москвариум','culture','entertainment',55.8352,37.6193,'Москвариум'],
['Колесо обозрения «Солнце Москвы»','culture','entertainment',55.831,37.6351,'Солнце Москвы'],
['Музей «АТОМ» на ВДНХ','culture','museum',55.8389,37.6288,'Музей АТОМ'],
['Павильон «Космос» на ВДНХ','culture','museum',55.8373,37.6268,'Космос (павильон ВДНХ)'],
['Фонтан «Дружба народов»','sights','sights',55.8325,37.6291,'Дружба народов (фонтан)'],
['Фонтан «Каменный цветок»','sights','sights',55.8337,37.629,'Каменный цветок (фонтан, ВДНХ)'],
['Музей криптографии','culture','museum',55.8037,37.5634,'Музей криптографии'],
['Культурный центр «Хлебозавод № 9»','culture','art',55.8043,37.5855,'Хлебозавод № 9'],
['Дизайн-завод «Флакон»','culture','art',55.804,37.5834,'Флакон (дизайн-завод)'],
['Центр современного искусства «Винзавод»','culture','art',55.7547,37.6669,'Винзавод (центр современного искусства)'],
['Центр дизайна Artplay','culture','art',55.7497,37.6696,'Artplay'],
['Культурный центр ЗИЛ','culture','art',55.6961,37.6577,'Культурный центр ЗИЛ'],
['Парк развлечений «Остров мечты»','culture','entertainment',55.6924,37.6713,'Остров мечты (парк развлечений)'],
['Парк развлечений «Сказка»','culture','entertainment',55.774,37.4373,''],
['Парк «Тюфелева роща»','parks','parks',55.6923,37.6267,'Тюфелева роща'],
['Сад имени Баумана','parks','parks',55.767,37.6622,'Сад имени Баумана'],
['Чистопрудный бульвар','sights','sights',55.762,37.6415,'Чистопрудный бульвар'],
['Гоголевский бульвар','sights','sights',55.7501,37.602,'Гоголевский бульвар'],
['Рождественский бульвар','sights','sights',55.7658,37.631,'Рождественский бульвар'],
['Цветной бульвар','sights','sights',55.7712,37.6199,'Цветной бульвар'],
['Никитский бульвар','sights','sights',55.7577,37.5991,'Никитский бульвар'],
['Покровский бульвар','sights','sights',55.7592,37.647,'Покровский бульвар'],
['Яузский бульвар','sights','sights',55.7494,37.6526,'Яузский бульвар'],
['Новодевичьи пруды','parks','parks',55.7274,37.5574,'Новодевичьи пруды'],
['Новодевичий монастырь','sights','sights',55.7269,37.5571,'Новодевичий монастырь'],
['Спорткомплекс «Лужники»','culture','entertainment',55.7158,37.5534,'Лужники'],
['Смотровая площадка «Панорама 360»','water','viewpoint',55.7488,37.5398,'Башня Федерация'],
['Дом на набережной','sights','sights',55.7444,37.6101,'Дом на набережной'],
['Культурный квартал «Красный Октябрь»','culture','art',55.7427,37.608,'Красный Октябрь (кондитерская фабрика)'],
['Крымский мост','water','viewpoint',55.7348,37.5986,'Крымский мост (Москва)'],
['Природный парк «Крылатские холмы»','parks','parks',55.7559,37.4224,'Крылатские холмы'],
['Парк «Дубки»','parks','parks',55.8183,37.5667,'Дубки (парк, Москва)'],
['Гончаровский парк','parks','parks',55.8188,37.594,'Гончаровский парк'],
['Парк «Акведук»','parks','parks',55.8351,37.6635,'Парк «Акведук»'],
['Усадьба «Свиблово»','sights','sights',55.8603,37.6445,'Усадьба Свиблово'],
['Парк «Олимпийская деревня»','parks','parks',55.6778,37.5018,'Парк Олимпийской деревни'],
['Парк Дружбы у Речного вокзала','parks','parks',55.86,37.466,'Парк Дружбы (Москва)']
];
// Only venue-specific publicly published bills; never infer live pricing from category.
const checks={
 '«Шава-гриль» в Ясенево':{label:'до 1 000 ₽',source:'https://www.afisha.ru/msk/restaurant/shava-gril-442915/'},
 'Кафе «Оазис» в Ясенево':{label:'1 200–1 400 ₽',source:'https://yandex.com/maps/org/oazis/1039665596/'},
 'Кафе «Пушкинъ»':{label:'3 000–4 000 ₽',source:'https://www.restoran.ru/msk/detailed/restaurants/cafepushkin/'},
 'Кондитерская «Кафе Пушкинъ»':{label:'1 000–2 000 ₽',source:'https://allcafe.ru/msk/restoran/kafe-pushkin/'}
};
// City-wide verified metro station anchors let walking routes work when public
// geocoders are blocked by CORS or a mobile carrier.
const metroAliases=[
 {name:'Метро «Ясенево»',lat:55.606306,lng:37.533406,aliases:['метро ясенево','станция метро ясенево','м ясенево','yasenevo metro','yasenevo subway'],source:'https://vmetro.moscow/station/yasenevo/'},
 {name:'Метро «Рязанский проспект»',lat:55.717546,lng:37.793593,aliases:['рязанский проспект','метро рязанский проспект','станция метро рязанский проспект','м рязанский проспект','ryazansky prospekt metro'],source:'https://s3.t2.ru/ds-site/bcc_media/content/dokumenty/goroda-i-koordinaty-m3530005.pdf'}
];
// Published opening hours; exceptional closures still require checking the source.
const hours={
 'Парк Горького':{value:'24/7',source:'https://www.park-gorkogo.ru/faq/',checked:'2026-11-19'},
 'Парк «Зарядье»':{value:'24/7',source:'https://yandex.by/maps/org/zaryadye/205689235916/',checked:'2026-11-19'}
};
const items=raw.map(([name,type,category,lat,lng,wiki,address],i)=>({
  id:'curated-msk-'+i,name,type,category,lat,lng,
  address:address||name+', Москва',tags:{...(wiki?{wikipedia:'ru:'+wiki}:{}),...(hours[name]?{opening_hours:hours[name].value}:{})},hoursSource:hours[name]?.source||null,
  source:'curated',check:checks[name]||null
}));
const norm=s=>String(s||'').toLocaleLowerCase('ru').replace(/ё/g,'е').replace(/[«»"']/g,'').replace(/[^\p{L}\p{N} ]/gu,' ').replace(/\s+/g,' ').trim();
function haversine(a,b){
 if(!a||!b||!Number.isFinite(a.lat)||!Number.isFinite(a.lng))return Infinity;
 const y=(b.lat-a.lat)*111.2,x=(((b.lng-a.lng+540)%360)-180)*111.2*Math.cos((a.lat+b.lat)*Math.PI/360);
 return Math.hypot(x,y);
}
function metroLookup(q){
 const term=norm(q);
 for(const item of metroAliases)if(item.aliases.some(alias=>norm(alias)===term))
  return {id:'metro-'+item.name,name:item.name,lat:item.lat,lng:item.lng,category:'metro',type:'transit',address:item.name+', Москва',source:'verified-metro',coordinatesSource:item.source,tags:{}};
 return null;
}
function lookup(q){
 const metro=metroLookup(q);if(metro)return metro;
 const term=norm(q);if(term.length<3)return null;
 const found=items.find(p=>norm(p.name)===term||norm(p.address)===term);
 if(found)return found;
 const ranked=items.map(p=>({p,n:norm(p.name)})).filter(x=>(x.n.includes(term)||term.includes(x.n))&&x.n.length>=4);
 ranked.sort((a,b)=>Math.abs(a.n.length-term.length)-Math.abs(b.n.length-term.length));
 return ranked[0]?.p||null;
}
// Shared by the planner and tests: explicit interests take precedence over broad style.
const interestCategories={parks:['parks'],photo:['viewpoint','sights','water','art'],architecture:['sights'],cafe:['cafe'],restaurant:['restaurant'],dessert:['bakery'],museum:['museum'],theatre:['theatre'],cinema:['cinema'],viewpoint:['viewpoint'],water:['water','viewpoint'],nature:['parks'],shopping:['malls'],entertainment:['entertainment'],quest:['quest'],cycling:['parks','water'],picnic:['parks'],pets:['parks','water'],kids:['parks','entertainment'],art:['art'],books:['books'],history:['sights','museum']};
function matches(p,{style='all',interests=[],rain=false,avoidMalls=false}={}){
 if(avoidMalls&&p.type==='malls')return false;
 if(rain&&!['food','culture','books','malls'].includes(p.type))return false;
 const categories=interests.flatMap(k=>interestCategories[k]||[]);
 if(categories.length)return categories.includes(p.category)||categories.includes(p.type);
 if(style==='all'||style==='direct')return ['parks','water','sights','culture','books'].includes(p.type);
 return p.type===style||p.category===style;
}
function selectStops(pool,targets,{start,end,style='all',interests=[],rain=false,avoidMalls=false,excluded=[],skipFood=false,maxDistance=3}={}){
 const used=new Set(excluded);for(const p of [start,end])if(p){used.add(p.id);used.add(norm(p.name));}
 const foodInterests=interests.filter(k=>['cafe','restaurant','dessert'].includes(k));
 const scenicInterests=interests.filter(k=>!foodInterests.includes(k));
 const foodWanted=!skipFood; // One optional meal stop, removable in the itinerary.
 const available=p=>!used.has(p.id)&&!used.has(norm(p.name))&&[start,end].every(x=>!x||haversine(x,p)>.045);
 const choose=(target,food)=>{
  const choices=pool.filter(p=>available(p)&&(food?p.type==='food':p.type!=='food')&&matches(p,{style:food?'food':style==='food'||foodInterests.length&&!scenicInterests.length?'all':style,interests:food?foodInterests:scenicInterests,rain,avoidMalls}))
    .map(p=>({p,d:haversine(target,p)})).filter(x=>x.d<=maxDistance).sort((a,b)=>(a.d-(a.p.check?.label?.length?0.35:0))-(b.d-(b.p.check?.label?.length?0.35:0)));
  const p=choices[0]?.p;if(p){used.add(p.id);used.add(norm(p.name));}return p;
 };
 const result=targets.map(t=>choose(t,false)).filter(Boolean);
 if(foodWanted){const p=choose(targets[Math.floor(targets.length/2)]||start,true);if(p)result.splice(Math.floor(result.length/2),0,p);}
 return result;
}
window.CityRoutePlaces={items,haversine,norm,lookup,metroLookup,matches,selectStops,interestCategories};
})();